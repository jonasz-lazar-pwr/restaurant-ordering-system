# api/utils.py

def simulate_qr_scan(table_numer: int):
    return f'Table {table_numer} scanned'