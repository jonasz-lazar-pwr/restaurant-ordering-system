# Change ID, POS_ID and SECRET after switching to proper shop
PAYU_CLIENT_ID = "490096"
PAYU_CLIENT_SECRET = "585ec418430275c1252a591b7ef07185"
PAYU_MERCHANT_POS_ID = "490096"
PAYU_SANDBOX_URL = "https://secure.snd.payu.com/"
