# tests/test_payment_service.py

# import pytest
# from fastapi.testclient import TestClient
# from payment_service.api.main import app
# from payment_service.api.core.payu_client import PayUClient
# from payment_service.api.core.exceptions import PayUError, OrderError